use opentelemetry::trace::{Span, Tracer, TracerProvider};
use opentelemetry_sdk::trace::SdkTracerProvider;
use regorus::{Engine, Value};
use ruvector_core::{
    types::{DbOptions, DistanceMetric, SearchQuery, VectorEntry},
    VectorDB,
};
use std::collections::HashMap;

fn ruvector(mode: &str) -> Result<(), String> {
    let db = VectorDB::new(DbOptions {
        dimensions: 8,
        distance_metric: DistanceMetric::Euclidean,
        storage_path: "memory://readiness".into(),
        hnsw_config: None,
        quantization: None,
    })
    .map_err(|e| e.to_string())?;
    let vector = if mode == "success" {
        vec![0.2; 8]
    } else {
        vec![0.2; 3]
    };
    let result = db.insert(VectorEntry {
        id: Some("incident-analogue".into()),
        vector,
        metadata: Some(HashMap::from([(
            "kind".into(),
            serde_json::json!("incident"),
        )])),
    });
    if mode == "failure" {
        if result.is_ok() {
            return Err("RuVector accepted a wrong vector dimension".into());
        }
        println!("RUVECTOR_DIMENSION_FAILURE_ASSERTED");
        return Ok(());
    }
    result.map_err(|e| e.to_string())?;
    let hits = db
        .search(SearchQuery {
            vector: vec![0.25; 8],
            k: 1,
            filter: None,
            ef_search: None,
        })
        .map_err(|e| e.to_string())?;
    if hits.first().map(|x| x.id.as_str()) != Some("incident-analogue") {
        return Err("RuVector search did not retrieve inserted analogue".into());
    }
    println!("RUVECTOR_INSERT_SEARCH_PASS");
    Ok(())
}

fn regorus(mode: &str) -> Result<(), String> {
    let mut engine = Engine::new();
    if mode == "failure" {
        if engine
            .add_policy("bad.rego".into(), "package {".into())
            .is_ok()
        {
            return Err("Regorus accepted malformed policy".into());
        }
        println!("REGORUS_MALFORMED_POLICY_FAILURE_ASSERTED");
        return Ok(());
    }
    engine.add_policy(
        "recovery.rego".into(),
        "package recovery\ndefault allow := false\nallow if { input.sensitivity == \"internal\" }".into(),
    ).map_err(|e| e.to_string())?;
    engine.set_input(
        Value::from_json_str("{\"sensitivity\":\"internal\"}").map_err(|e| e.to_string())?,
    );
    if engine
        .eval_rule("data.recovery.allow".into())
        .map_err(|e| e.to_string())?
        != Value::Bool(true)
    {
        return Err("Regorus did not authorize valid recovery input".into());
    }
    println!("REGORUS_POLICY_EVALUATION_PASS");
    Ok(())
}

fn telemetry(mode: &str) -> Result<(), String> {
    if mode == "failure" {
        if opentelemetry::trace::TraceId::from_hex("not-a-trace-id").is_ok() {
            return Err("OpenTelemetry accepted malformed trace id".into());
        }
        println!("OPENTELEMETRY_INVALID_TRACE_FAILURE_ASSERTED");
        return Ok(());
    }
    let provider = SdkTracerProvider::builder().build();
    let tracer = provider.tracer("resilience-readiness");
    let mut span = tracer.start("incident.readiness");
    span.add_event("selected-boundary-executed", Vec::new());
    span.end();
    provider.shutdown().map_err(|e| e.to_string())?;
    println!("OPENTELEMETRY_SPAN_PASS");
    Ok(())
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let result = match args.get(1).map(String::as_str) {
        Some("ruvector") => ruvector(args.get(2).map(String::as_str).unwrap_or("")),
        Some("regorus") => regorus(args.get(2).map(String::as_str).unwrap_or("")),
        Some("opentelemetry") => telemetry(args.get(2).map(String::as_str).unwrap_or("")),
        _ => Err("usage: probe ruvector|regorus|opentelemetry success|failure".into()),
    };
    if let Err(error) = result {
        eprintln!("{error}");
        std::process::exit(1);
    }
}
