#!/usr/bin/env bash
set -euo pipefail
export PATH=/home/ruv/.local/share/dream-machine/runtime/node-v24.21.0-linux-x64/bin:/home/ruv/.cargo/bin:$PATH
repo="$1"
mode="$2"
case "$repo" in
  ruvector|regorus|opentelemetry)
    exec cargo run --locked --quiet -- "$repo" "$mode"
    ;;
  agentdb|dspy|sublinear|ruflo)
    if test "$mode" = failure; then
      exec node upstreams/resilience-engine.mjs failure "$repo"
    fi
    payload='{"incident":"database latency threatens payment authorization","correlation_id":"readiness-probe"}'
    output="$(printf '%s' "$payload" | node upstreams/resilience-engine.mjs analyze)"
    case "$repo" in
      agentdb) printf '%s' "$output" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{let x=JSON.parse(s);if(x.agentdb.backend!=="agentdb-rvf-wasm"||x.agentdb.indexed<2)process.exit(1);console.log("AGENTDB_RVF_SEARCH_PASS")})' ;;
      dspy) printf '%s' "$output" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{let x=JSON.parse(s);if(x.dspy.demonstrations<3)process.exit(1);console.log("DSPY_BOOTSTRAP_FEWSHOT_PASS")})' ;;
      sublinear) printf '%s' "$output" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{let x=JSON.parse(s);if(!x.sublinear.converged)process.exit(1);console.log("SUBLINEAR_SOLVER_PASS")})' ;;
      ruflo) printf '%s' "$output" | node -e 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>{let x=JSON.parse(s);if(x.ruflo.topology!=="hierarchical")process.exit(1);console.log("RUFLO_TOPOLOGY_PASS")})' ;;
    esac
    ;;
  *) echo "unknown dependency: $repo" >&2; exit 2 ;;
esac
